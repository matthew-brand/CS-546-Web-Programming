// "I pledge my honor that I have abided by the Stevens Honor System" - Matthew Brand

const recipeData = require("./recipes");

module.exports = {
  recipes: recipeData
};
