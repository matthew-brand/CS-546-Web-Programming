// "I pledge my honor that I have abided by the Stevens Honor System" - Matthew Brand

const resultData = require("./palindrome");

module.exports = {
  result: resultData
};
