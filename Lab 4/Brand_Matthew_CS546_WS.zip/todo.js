// "I pledge my honor that I have abided by the Stevens Honor System" - Matthew Brand

const bluebird = require("bluebird");
const Promise = bluebird.Promise;

const fs = bluebird.promisifyAll(require("fs"));

const mongoCollections = require("./mongoCollections");
const todoItems = mongoCollections.todoItems;
const uuidv4 = require('uuid/v4');

function checkIsProperString(val, variableName) {
    if (typeof val !== "string") {
      throw `${variableName} is not a string`;
    }
}

exports.createTask = async function createTask(title, description) {
    if(title === undefined || !title) {
        throw "The title argument was not provided to createTask";
    }
    if(description === undefined || !description) {
        throw "The description argument was not provided to createTask";
    }
    checkIsProperString(title, "title");
    checkIsProperString(description, "description");

    const todoCollection = await todoItems();

    let newTask = {
        _id: uuidv4(),
        title: title,
        description: description,
        completed: false,
        completedAt: null
      };
  
      const insertInfo = await todoCollection.insertOne(newTask);
      if (insertInfo.insertedCount === 0) throw "Could not add task";
  
      const newId = insertInfo.insertedId;
  
      const task = await this.getTask(newId);
      return task;
}

exports.getAllTasks = async function getAllTasks() {
    const todoCollection = await todoItems();

    const Tasks = await todoCollection.find({}).toArray();

    return Tasks;
}

exports.getTask = async function getTask(id) {
    if(id === undefined || !id) {
        throw "The id argument was not provided to getTask";
    }
    checkIsProperString(id, "id");

    const todoCollection = await todoItems();
    const task = await todoCollection.findOne({ _id: id });
    if (task === null) throw "No task with that id";

    return task;
}

exports.completeTask = async function completeTask(id) {
    if(id === undefined || !id) {
        throw "The id argument was not provided to completeTask";
    }
    checkIsProperString(id, "id");

    const todoCollection = await todoItems();
    const updatedTask = {
      completed: true,
      completedAt: new Date()
    };

    var newvalues = {
        $set: updatedTask
    };

    const updateInfo = await todoCollection.updateOne({ _id: id }, newvalues);
    if (updateInfo.modifiedCount === 0) {
      throw "Could not update task successfully";
    }

    return await this.getTask(id);
}

exports.removeTask = async function removeTask(id) {
    if(id === undefined || !id) {
        throw "The id argument was not provided to removeTask";
    }
    checkIsProperString(id, "id");

    const todoCollection = await todoItems();
    const deletionInfo = await todoCollection.removeOne({ _id: id });

    if (deletionInfo.deletedCount === 0) {
      throw `Could not delete task with id of ${id}`;
    }
}