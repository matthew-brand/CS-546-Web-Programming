// "I pledge my honor that I have abided by the Stevens Honor System" - Matthew Brand

function checkIsProperObject(val, variableName) {
    if (typeof val !== "object") {
      throw `${variableName} is not an object`;
    }
}

function checkIsProperArray(val, variableName) {
    if (!Array.isArray(val)) {
      throw `${variableName} is not an array`;
    }
}

function checkIsProperString(val, variableName) {
    if (typeof val !== "string") {
      throw `${variableName} is not a string`;
    }
}

module.exports = {
    deepEquality: (obj1, obj2) => {
        if(obj1 === undefined) {
            throw 'The obj1 argument was not provided';
        } else if(obj2 === undefined) {
            throw 'The obj2 argument was not provided';
        } else {
            checkIsProperObject(obj1, "obj1");
            checkIsProperObject(obj2, "obj2");
            return JSON.stringify(obj1) === JSON.stringify(obj2);
        }
    },
    uniqueElements: (arr) => {
        if(arr === undefined) {
            throw 'The arr argument was not provided';
        } else {
            checkIsProperArray(arr, "arr");
            let arr2 = [];
            arr.forEach(element => {
                if(!arr2.includes(element)) {
                    arr2.push(element);
                }
            });
            return arr2.length;
        }
    },
    countOfEachCharacterInString: (str) => {
        if(str === undefined) {
            throw 'The str argument was not provided';
        } else {
            checkIsProperString(str, "str");
            let myObj = {};
            for(var i = 0; i < str.length; i++) {
                myObj[str.charAt(i)] = (str.match(new RegExp(str.charAt(i), "g")) || []).length;
            }
            return myObj;
        }
    }
};