// "I pledge my honor that I have abided by the Stevens Honor System" - Matthew Brand

const aboutData = require("./about");
const educationData = require("./education");
const storyData = require("./story");

module.exports = {
  about: aboutData,
  education: educationData,
  story: storyData
};
