// "I pledge my honor that I have abided by the Stevens Honor System" - Matthew Brand

const bluebird = require("bluebird");
const Promise = bluebird.Promise;

const fs = bluebird.promisifyAll(require("fs"));

function checkIsProperString(val, variableName) {
    if (typeof val !== "string") {
      throw `${variableName} is not a string`;
    }
}

exports.simplify = function simplify(text) {
    if(text === undefined || !text) {
        throw "The text argument was not provided to simplify";
    }

    checkIsProperString(text, "text");

    let textLowerCase = text.toLowerCase();
    let textReplaced = textLowerCase.replace(/[^A-Za-z\s]/g,'');
    let textSpaces = textReplaced.replace(/\s/g, ' ');
    let textSingleSpaces = textSpaces.replace(/ +(?= )/g, '');
    let textTrimmed = textSingleSpaces.trim();
    return textTrimmed;
};

exports.createMetrics = function createMetrics(text) {
    if(text === undefined || !text) {
        throw "The text argument was not provided to createMetrics";
    }

    checkIsProperString(text, "text");

    let metrics = {
        totalLetters: 0,
        totalWords: 0,
        uniqueWords: 0,
        longWords: 0,
        averageWordLength: 0,
        wordOccurences: {"": 0}
    };
    metrics.totalLetters = text.replace(/[^a-zA-Z]/g, '').length;
    let wordArray = text.split(" ");
    metrics.totalWords = wordArray.length;
    let dict = {};
    wordArray.forEach(word => {
        if(dict[word] == null) {
            dict[word] = 1;
        } else {
            dict[word] = dict[word] + 1;
        }
    });
    let uniqueArray = Object.keys(dict);
    metrics.uniqueWords = uniqueArray.length;
    let countLongWords = 0;
    wordArray.forEach(word => {
        if(word.length >= 6) {
            countLongWords++;
        }
    });
    metrics.longWords = countLongWords;
    metrics.averageWordLength = metrics.totalLetters / metrics.totalWords;
    metrics.wordOccurences = dict;
    return metrics;
};